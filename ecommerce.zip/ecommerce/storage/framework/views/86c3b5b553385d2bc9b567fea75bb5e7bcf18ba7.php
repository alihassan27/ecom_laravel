
<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('dashboard', 'active'); ?>
<?php $__env->startSection('container'); ?>
<div class="row">
    <h1>Dashboard</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laragon\www\ecommerce\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>