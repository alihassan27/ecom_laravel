
<?php $__env->startSection('page_title', 'Cart Page'); ?>
<?php $__env->startSection('container'); ?>

<!-- Cart view section -->
<section id="cart-view">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="cart-view-area">
          <div class="cart-view-table">
            <form action="">
              <?php if(isset($list[0])): ?>
              <div class="table-responsive">
                <table class="table">
                  <thead>
                    <tr>
                      <th></th>
                      <th></th>
                      <th>Product</th>
                      <th>Price</th>
                      <th>Quantity</th>
                      <th>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr id="cart_box<?php echo e($data->attr_id); ?>">
                      <td><a class="remove" href="javascript:void(0)" onclick="deleteCartProduct('<?php echo e($data->pid); ?>','<?php echo e($data->size); ?>','<?php echo e($data->color); ?>','<?php echo e($data->attr_id); ?>')">
                          <fa class="fa fa-close"></fa>
                        </a></td>
                      <td><a href="<?php echo e(url('product/'. $data->slug)); ?>"><img src="<?php echo e(asset('storage/media/'. $data->image)); ?>" alt="img"></a></td>
                      <td><a class="aa-cart-title" href="<?php echo e(url('product/'. $data->slug)); ?>"><?php echo e($data->name); ?></a> <br>
                        <?php if($data->size != 0): ?>
                        Size: <?php echo e($data->size); ?><br>
                        <?php endif; ?>
                        <?php if($data->color != 0): ?>
                        Color: <?php echo e($data->color); ?><br>
                        <?php endif; ?>
                      </td>
                      <td><?php echo e($data->price); ?></td>
                      <td><input class="aa-cart-quantity" type="number" id="qty<?php echo e($data->attr_id); ?>" onchange="updateQty('<?php echo e($data->pid); ?>','<?php echo e($data->size); ?>','<?php echo e($data->color); ?>','<?php echo e($data->attr_id); ?>','<?php echo e($data->price); ?>')" value="<?php echo e($data->qty); ?>"></td>
                      <td id="total_price_<?php echo e($data->attr_id); ?>">Rs. <?php echo e($data->price*$data->qty); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td colspan="6" class="aa-cart-view-bottom">
                        <a class="aa-cartbox-checkout aa-primary-btn" href="<?php echo e(url('/checkout')); ?>">
                          <input class="aa-cart-view-btn" type="button" value="Checkout">
                        </a>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <?php else: ?>
              <h3>Cart Empty</h3>
              <?php endif; ?>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- / Cart view section -->

<input type="hidden" name="qty" id="qty" value="1">
<!-- / size and color id's -->
<form action="" id="frmAddToCart">
  <input type="hidden" id="size_id" name="size_id">
  <input type="hidden" id="color_id" name="color_id">
  <input type="hidden" id="pqty" name="pqty">
  <input type="hidden" id="product_id" name="product_id">
  <?php echo csrf_field(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laragon\www\ecommerce\resources\views/front/cart.blade.php ENDPATH**/ ?>