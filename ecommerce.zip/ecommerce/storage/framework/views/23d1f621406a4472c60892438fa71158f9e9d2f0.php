
<?php $__env->startSection('page_title', 'Order Detail'); ?>
<?php $__env->startSection('container'); ?>

<!-- Cart view section -->
<section id="cart-view">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
          <div class="order_detail">
            <h3>Delivery Address</h3>
            Name: <?php echo e($orders_details[0]->name); ?> <br>
            Address: <?php echo e($orders_details[0]->address); ?> <br>
            City: <?php echo e($orders_details[0]->city); ?> <br>
            State: <?php echo e($orders_details[0]->state); ?> <br>
            Pincode: <?php echo e($orders_details[0]->pincode); ?> <br>
            Mobile: <?php echo e($orders_details[0]->mobile); ?> <br>
          </div>
      </div>

      <div class="col-md-6">
          <div class="order_detail">
            <h3>Order Details</h3>
            Order Status: <?php echo e($orders_details[0]->orders_status); ?> <br>
            Payment Status: <?php echo e($orders_details[0]->payment_status); ?> <br>
            Payment Type: <?php echo e($orders_details[0]->payment_type); ?> <br>
            <?php
              if($orders_details[0]->payment_id != ''){
                echo 'Payment ID: '.$orders_details[0]->payment_id;
              }
            ?>            
          </div>
          <b>Track Detail: </b>
          <br> <?php echo e($orders_details[0]->track_details); ?>


        </div>

      <div class="col-md-12">
        <div class="cart-view-area">
          <div class="cart-view-table">
            <form action="">
              <div class="table-responsive">
                <table class="table">
                  <thead>
                    <tr>
                      <th>Product</th>
                      <th>Image</th>
                      <th>Size</th>
                      <th>Color</th>
                      <th>Price</th>
                      <th>Qty</th>
                      <th>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    $totalAmt = 0;
                    ?>
                    <?php $__currentLoopData = $orders_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $totalAmt = $totalAmt + ($list->price * $list->qty);
                    ?>
                    <tr>
                      <td><?php echo e($list->pname); ?></td>
                      <td><img src='<?php echo e(asset('storage/media/'.$list->attr_image)); ?>' alt=""></td>
                      <td><?php echo e($list->size); ?></td>
                      <td><?php echo e($list->color); ?></td>
                      <td><?php echo e($list->price); ?></td>
                      <td><?php echo e($list->qty); ?></td>
                      <td><?php echo e($list->price * $list->qty); ?></td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td colspan="5">&nbsp;</td>
                      <td><b>Total</b></td>
                      <td><b><?php echo e($totalAmt); ?></b></td>
                    </tr>

                    <?php
                    if($orders_details[0]->coupon_value>0){                    
                    echo '<tr>
                    <td colspan="5">&nbsp;</td>
                    <td><b>Coupon <span class="cart_color">('.$orders_details[0]->coupon_code.')</span></b></td>
                    <td>'.$orders_details[0]->coupon_value.'</td>
                    </tr>';
                    $totalAmt = $totalAmt - $orders_details[0]->coupon_value;
                    echo '<tr>
                    <td colspan="5">&nbsp;</td>
                    <td><b>Final Total</b></td>
                    <td><b>'.$totalAmt.'</b></td>
                    </tr>';
                    }
                    ?>
                  </tbody>
                </table>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- / Cart view section -->

<input type="hidden" name="qty" id="qty" value="1">
<!-- / size and color id's -->
<form action="" id="frmAddToCart">
  <input type="hidden" id="size_id" name="size_id">
  <input type="hidden" id="color_id" name="color_id">
  <input type="hidden" id="pqty" name="pqty">
  <input type="hidden" id="product_id" name="product_id">
  <?php echo csrf_field(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laragon\www\ecommerce\resources\views/front/order_detail.blade.php ENDPATH**/ ?>