<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo $__env->yieldContent('page_title'); ?></title>
  <link href="<?php echo e(asset('front_assets/css/font-awesome.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('front_assets/css/bootstrap.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('front_assets/css/jquery.smartmenus.bootstrap.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front_assets/css/jquery.simpleLens.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front_assets/css/slick.css')); ?>">
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('front_assets/css/nouislider.css')); ?>">
  <link id="switcher" href="<?php echo e(asset('front_assets/css/theme-color/default-theme.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('front_assets/css/sequence-theme.modern-slide-in.css')); ?>" rel="stylesheet" media="all">
  <link href="<?php echo e(asset('front_assets/css/style.css')); ?>" rel="stylesheet">

  <!-- Google Font -->
  <link href='https://fonts.googleapis.com/css?family=Lato' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Raleway' rel='stylesheet' type='text/css'>


  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

  <style>
    .lead_time {
      color: red;
      margin-top: -12px;
      font-size: 11px;
      font-weight: bold;
    }

    .active_color {
      border: 3px solid pink;
    }

    .left_cat_active {
      font-weight: bold;
    }

    .aa-login-form input[type="email"] {
      border: 1px solid #ccc;
      font-size: 16px;
      height: 40px;
      margin-bottom: 15px;
      padding: 10px;
      width: 100%;
    }

    .field_error {
      color: red;
    }

    .coupon_code input {
      border: 1px solid #ccc;
      height: 40px;
      padding: 10px;
      width: 100%;
      margin-bottom: 15px;
    }

    .cart_color {
      font-size: 14px;
      font-weight: bold;
      color: green;
    }

    .remove_coupon_Code_link {
      color: red;
      font-size: 12px;
    }

    #order_place_msg {
      color: red;
      font-size: 16px;
    }

    .order_detail {
      margin-bottom: 10px;
      font-weight: bold;
      line-height: 25px;
    }

    .order_id_btn {
      background: red;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 14px;
      font-weight: bold;
      color: #000;
    }

    .order_id_btn a {
      color: #fff;
    }
  </style>

  <script>
    var PRODUCT_IMAGE = "<?php echo e(asset('storage/media/')); ?>";
  </script>
</head>

<body class="productPage">
  <!-- wpf loader Two -->
  <div id="wpf-loader-two">
    <div class="wpf-loader-two-inner">
      <span>Loading</span>
    </div>
  </div>
  <!-- / wpf loader Two -->
  <!-- SCROLL TOP BUTTON -->
  <a class="scrollToTop" href="#"><i class="fa fa-chevron-up"></i></a>
  <!-- END SCROLL TOP BUTTON -->


  <!-- Start header section -->
  <header id="aa-header">
    <!-- start header top  -->
    <div class="aa-header-top">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="aa-header-top-area">
              <!-- start header top left -->
              <div class="aa-header-top-left">

                <!-- start cellphone -->
                <div class="cellphone hidden-xs">
                  <p><span class="fa fa-phone"></span>00-62-658-658</p>
                </div>
                <!-- / cellphone -->
              </div>
              <!-- / header top left -->
              <div class="aa-header-top-right">
                <ul class="aa-head-top-nav-right">

                  <li class="hidden-xs"><a href="<?php echo e(url('/cart')); ?>">My Cart</a></li>
                  <?php if(session()->has('FRONT_USER_LOGIN') != null): ?>
                  <li><a href="<?php echo e(url('/order')); ?>">My Orders</a></li>
                  <li><a href="<?php echo e(url('/logout')); ?>">Logout</a></li>
                  <?php else: ?>
                  <li><a href="" data-toggle="modal" data-target="#login-modal">Login</a></li>
                  <?php endif; ?>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- / header top  -->

    <!-- start header bottom  -->
    <div class="aa-header-bottom">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="aa-header-bottom-area">
              <!-- logo  -->
              <div class="aa-logo">
                <!-- Text based logo -->
                <a href="<?php echo e(url('/')); ?>">
                  <span class="fa fa-shopping-cart"></span>
                  <p>Ali's<strong> Shop</strong> <span>Your Shopping Partner</span></p>
                </a>
                <!-- img based logo -->
                <!-- <a href="javascript:void(0)"><img src="img/logo.jpg" alt="logo img"></a> -->
              </div>
              <!-- / logo  -->
              <!-- cart box -->
              <?php
              $getAddToCartTotalItem = getAddToCartTotalItem();
              $totalCartItem = count($getAddToCartTotalItem);
              $totalPrice = 0;
              ?>
              <div class="aa-cartbox">
                <a class="aa-cart-link" href="javasvript:void(0)" id="cartBox">
                  <span class="fa fa-shopping-basket"></span>
                  <span class="aa-cart-title">SHOPPING CART</span>
                  <span class="aa-cart-notify"><?php echo e($totalCartItem); ?></span>
                </a>
                <div class="aa-cartbox-summary">
                  <?php if($totalCartItem > 0): ?>
                  <ul>
                    <?php $__currentLoopData = $getAddToCartTotalItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    $totalPrice = $totalPrice + ($cartItem->price * $cartItem->qty);
                    ?>
                    <li>
                      <a class="aa-cartbox-img" href="<?php echo e(asset('storage/media/'. $cartItem->image)); ?>"><img src="<?php echo e(asset('storage/media/'. $cartItem->image)); ?>" alt="img"></a>
                      <div class="aa-cartbox-info">
                        <h4><a href="#"><?php echo e($cartItem->name); ?></a></h4>
                        <p><?php echo e($cartItem->qty); ?> x Rs. <?php echo e($cartItem->price); ?></p>
                      </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li>
                      <span class="aa-cartbox-total-title">
                        Total
                      </span>
                      <span class="aa-cartbox-total-price">
                        Rs. <?php echo e($totalPrice); ?>

                      </span>
                    </li>
                  </ul>
                  <a class="aa-cartbox-checkout aa-primary-btn" href="<?php echo e(url('/cart')); ?>">Cart</a>
                  <?php endif; ?>
                </div>
              </div>
              <!-- / cart box -->
              <!-- search box -->
              <div class="aa-search-box">
                <form action="">
                  <input type="text" id="search_str" placeholder="Search here ex. 'man' ">
                  <button type="button" onclick="funSearch()"><span class="fa fa-search"></span></button>
                </form>
              </div>
              <!-- / search box -->
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- / header bottom  -->
  </header>
  <!-- / header section -->
  <!-- menu -->
  <section id="menu">
    <div class="container">
      <div class="menu-area">
        <!-- Navbar -->
        <div class="navbar navbar-default" role="navigation">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
          </div>
          <div class="navbar-collapse collapse">
            <!-- Left nav -->

            <?php echo getTopNavCat(); ?>


          </div><!--/.nav-collapse -->
        </div>
      </div>
    </div>
  </section>
  <!-- / menu -->
  <!-- Start slider -->

  <?php $__env->startSection('container'); ?>
  <?php echo $__env->yieldSection(); ?>

  <!-- footer -->
  <footer id="aa-footer">
    <!-- footer bottom -->
    <div class="aa-footer-top">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="aa-footer-top-area">
              <div class="row">
                <div class="col-md-3 col-sm-6">
                  <div class="aa-footer-widget">
                    <h3>Main Menu</h3>
                    <ul class="aa-footer-nav">
                      <li><a href="#">Home</a></li>
                      <li><a href="#">Our Services</a></li>
                      <li><a href="#">Our Products</a></li>
                      <li><a href="#">About Us</a></li>
                      <li><a href="#">Contact Us</a></li>
                    </ul>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="aa-footer-widget">
                    <div class="aa-footer-widget">
                      <h3>Knowledge Base</h3>
                      <ul class="aa-footer-nav">
                        <li><a href="#">Delivery</a></li>
                        <li><a href="#">Returns</a></li>
                        <li><a href="#">Services</a></li>
                        <li><a href="#">Discount</a></li>
                        <li><a href="#">Special Offer</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="aa-footer-widget">
                    <div class="aa-footer-widget">
                      <h3>Useful Links</h3>
                      <ul class="aa-footer-nav">
                        <li><a href="#">Site Map</a></li>
                        <li><a href="#">Search</a></li>
                        <li><a href="#">Advanced Search</a></li>
                        <li><a href="#">Suppliers</a></li>
                        <li><a href="#">FAQ</a></li>
                      </ul>
                    </div>
                  </div>
                </div>
                <div class="col-md-3 col-sm-6">
                  <div class="aa-footer-widget">
                    <div class="aa-footer-widget">
                      <h3>Contact Us</h3>
                      <address>
                        <p> 25 Astor Pl, NY 10003, USA</p>
                        <p><span class="fa fa-phone"></span>+1 212-982-4589</p>
                        <p><span class="fa fa-envelope"></span>dailyshop@gmail.com</p>
                      </address>
                      <div class="aa-footer-social">
                        <a href="#"><span class="fa fa-facebook"></span></a>
                        <a href="#"><span class="fa fa-twitter"></span></a>
                        <a href="#"><span class="fa fa-google-plus"></span></a>
                        <a href="#"><span class="fa fa-youtube"></span></a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- footer-bottom -->
    <div class="aa-footer-bottom">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="aa-footer-bottom-area">
              <p>Designed by <a href="http://www.markups.io/">MarkUps.io</a></p>
              <div class="aa-footer-payment">
                <span class="fa fa-cc-mastercard"></span>
                <span class="fa fa-cc-visa"></span>
                <span class="fa fa-paypal"></span>
                <span class="fa fa-cc-discover"></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <!-- / footer -->

  <?php
  if(isset($_COOKIE['login_email']) && isset($_COOKIE['login_pwd'])){
  $login_email = $_COOKIE['login_email'];
  $login_pwd = $_COOKIE['login_pwd'];
  $is_remember = "checked='checked'";
  }else{
  $login_email = '';
  $login_pwd = '';
  $is_remember = '';
  }
  ?>

  <!-- Login Modal -->
  <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-body">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <div id="pop_login">
            <h4>Login or Register</h4>
            <form class="aa-login-form" action="" id="frmLogin">
              <label for="">Email address<span>*</span></label>
              <input type="email" placeholder="Email" name="str_login_email" value="<?php echo e($login_email); ?>" required>
              <label for="">Password<span>*</span></label>
              <input type="password" placeholder="Password" name="str_login_password" value="<?php echo e($login_pwd); ?>" required>
              <button class="aa-browse-btn" type="submit" id="btnLogin">Login</button>
              <label for="rememberme" class="rememberme"><input type="checkbox" id="rememberme" name="rememberme" <?php echo e($is_remember); ?>> Remember me </label>
              <div id="login_msg" class="field_error" style="clear: both;" class=""></div>
              OR <br>
              <a href="<?php echo e(route('google-auth')); ?>" class="btn btn-success">Continue with Google</a>
              <p class="aa-lost-password"><a href="javascript:void(0)" onclick="forgot_password()">Lost your password?</a></p>
              <div class="aa-register-now">
                Don't have an account?<a href="<?php echo e(url('registration')); ?>">Register now!</a>
              </div>
              <?php echo csrf_field(); ?>
            </form>
          </div>
          <div id="pop_forgot" style="display: none;">
            <h4>Forgot Password</h4>
            <form class="aa-login-form" action="" id="frmForgot">
              <label for="">Email address<span>*</span></label>
              <input type="email" placeholder="Email" name="str_forgot_email" required>
              <button class="aa-browse-btn" type="submit" id="btnForgot">Submit</button>
              <br><br>
              <div class="aa-register-now">
                Login Form<a href="javascript:void(0)" onclick="show_login_popup()">Login now!</a>
              </div>
              <div id="forgot_msg" class="field_error" style="clear: both;" class=""></div>
              <?php echo csrf_field(); ?>
            </form>
          </div>

        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div>

  <!-- jQuery library -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="<?php echo e(asset('front_assets/js/bootstrap.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('front_assets/js/jquery.smartmenus.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('front_assets/js/jquery.smartmenus.bootstrap.js')); ?>"></script>
  <script src="<?php echo e(asset('front_assets/js/sequence.js')); ?>"></script>
  <script src="<?php echo e(asset('front_assets/js/sequence-theme.modern-slide-in.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('front_assets/js/jquery.simpleGallery.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('front_assets/js/jquery.simpleLens.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('front_assets/js/slick.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(asset('front_assets/js/nouislider.js')); ?>"></script>
  <script src="<?php echo e(asset('front_assets/js/custom.js')); ?>"></script>

  <script>
    function change_product_color_image(img, color) {
      jQuery('#color_id').val(color);
      jQuery('.simpleLens-big-image-container').html('<a data-lens-image="' + img + '" class="simpleLens-lens-image"><img src="' + img + '" class="simpleLens-big-image"></a>');
    }

    function showColor(size) {
      jQuery('#size_id').val(size);
      jQuery('.product_color').hide();
      jQuery('.size_' + size).show();
      jQuery('size_link' + size).css('border', '1px solid #ddd');
      jQuery('#size_' + size).css('border', '1px solid black');
    }

    function home_add_to_cart(id, size_str_id, color_str_id) {
      jQuery('#color_id').val(color_str_id);
      jQuery('#size_id').val(size_str_id);
      add_to_cart(id, size_str_id, color_str_id);

    }

    function add_to_cart(id, size_str_id, color_str_id) {
      jQuery('#add_to_cart_msg').html("");
      var color_id = jQuery('#color_id').val();
      var size_id = jQuery('#size_id').val();

      if (size_str_id == 0 && color_str_id == 0) {
        size_id = 'no';
        color_id = 'no';
      }
      if (size_id == '' && size_id != 'no') {
        jQuery('#add_to_cart_msg').html('<div class="mt-3 alert alert-danger fade in alert-dismissible" role="alert"><a href="#" class="close" data-dismiss="alert" areal-label="close" title="close">x</a>Please Select Size</div>');
      } else if (color_id == '' && color_id != 'no') {
        jQuery('#add_to_cart_msg').html('<div class="mt-3 alert alert-danger fade in alert-dismissible" role="alert"><a href="#" class="close" data-dismiss="alert" areal-label="close" title="close">x</a>Please Select Color</div>');
      } else {
        jQuery('#product_id').val(id);
        jQuery('#pqty').val(jQuery('#qty').val());
        jQuery.ajax({
          url: "<?php echo e(url('add_to_cart')); ?>",
          data: jQuery('#frmAddToCart').serialize(),
          type: 'post',
          success: function(result) {
            var totalPrice = 0;
            alert(result.msg);
            if (result.totalItem == 0) {
              jQuery('.aa-cart-notify').html('0');
              jQuery('.aa-cartbox-summary').remove();
              console.log(result.totalItem);
            } else {
              jQuery('.aa-cart-notify').html(result.totalItem);
              var html = '<ul>';
              jQuery.each(result.data, function(arrKey, arrVal) {
                totalPrice = parseInt(totalPrice) + (parseInt(arrVal.qty) * parseInt(arrVal.price));
                html += '<li><a class="aa-cartbox-img" href="#"><img src="' + PRODUCT_IMAGE + '/' + arrVal.image + '" alt="img"></a><div class="aa-cartbox-info"><h4><a href="#">' + arrVal.name + '</a></h4><p>' + arrVal.qty + ' x Rs ' + arrVal.price + '</p></div></li>';
              });
            }
            html += '<li><span class="aa-cartbox-total-title">Total</span><span class="aa-cartbox-total-price">Rs. ' + totalPrice + ' </span></li>';
            html += '</ul><a class="aa-cartbox-checkout aa-primary-btn" href="cart">Cart</a>';
            console.log(html);
            jQuery('.aa-cartbox-summary').html(html);
          }
        })
      }
    }

    function updateQty(pid, size, color, attr_id, price) {
      jQuery('#size_id').val(size);
      jQuery('#color_id').val(color);
      var qty = jQuery('#qty' + attr_id).val();
      jQuery('#qty').val(qty);
      add_to_cart(pid, size, color);
      jQuery('#total_price_' + attr_id).html('Rs. ' + qty * price);
    }

    function deleteCartProduct(pid, size, color, attr_id) {
      jQuery('#size_id').val(size);
      jQuery('#color_id').val(color);
      jQuery('#qty').val(0);
      add_to_cart(pid, size, color);
      //jQuery('#total_price_'+attr_id).html('Rs. '+qty*price);
      jQuery('#cart_box' + attr_id).remove();
    }

    function sort_by() {
      var sort_by = jQuery('#sort_by_value').val();
      jQuery('#sort').val(sort_by);
      jQuery('#categoryFilter').submit();
    }

    function sort_price_filter() {
      var start = jQuery('#skip-value-lower').html();
      var end = jQuery('#skip-value-upper').html();
      jQuery('#filter_price_start').val(start);
      jQuery('#filter_price_end').val(end);
      jQuery('#categoryFilter').submit();
    }

    function setColor(color, type) {
      var color_str = jQuery('#color_filter').val();
      if (type == 1) {
        var new_color_str = color_str.replace(color + ':', '');
        jQuery('#color_filter').val(new_color_str);
      } else {
        jQuery('#color_filter').val(color + ':' + color_str);
      }
      jQuery('#categoryFilter').submit();
    }

    function funSearch() {
      var search_str = jQuery('#search_str').val();
      if (search_str != '' && search_str.length > 3) {
        window.location.href = '/search/' + search_str;
      }
    }

    jQuery('#frmRegistration').submit(function(e) {
      e.preventDefault();
      jQuery('.field_error').html('');
      jQuery.ajax({
        url: 'registration_process',
        data: jQuery('#frmRegistration').serialize(),
        type: 'post',
        success: function(result) {
          if (result.status == "error") {
            jQuery.each(result.error, function(key, val) {
              jQuery('#' + key + '_error').html(val[0]);
            });
          }
          if (result.status == "success") {
            jQuery('#frmRegistration')[0].reset();
            jQuery('#thank_you_msg').html(result.msg);

          }
        }
      })
    });

    jQuery('#frmLogin').submit(function(e) {
      jQuery('#login_msg').html('');
      e.preventDefault();
      jQuery.ajax({
        url: 'login_process',
        data: jQuery('#frmLogin').serialize(),
        type: 'post',
        success: function(result) {
          if (result.status == "error") {
            jQuery('#login_msg').html(result.msg);
          }
          if (result.status == "success") {
            window.location.href = window.location.href;
            //jQuery('#frmLogin')[0].reset();
            //jQuery('#thank_you_msg').html(result.msg);
          }
        }
      })
    });

    function forgot_password() {
      jQuery('#pop_forgot').show();
      jQuery('#pop_login').hide();
    }

    function show_login_popup() {
      jQuery('#pop_forgot').hide();
      jQuery('#pop_login').show();
    }

    jQuery('#frmForgot').submit(function(e) {
      jQuery('#forgot_msg').html('');
      e.preventDefault();
      jQuery.ajax({
        url: 'forgot_password',
        data: jQuery('#frmForgot').serialize(),
        type: 'post',
        success: function(result) {
          jQuery('#forgot_msg').html(result.msg);
        }
      })
    });

    jQuery('#frmUpdatePassword').submit(function(e) {
      jQuery('#thank_you_msg').html('');
      e.preventDefault();
      jQuery.ajax({
        url: '/forgot_password_change_process',
        data: jQuery('#frmUpdatePassword').serialize(),
        type: 'post',
        success: function(result) {
          jQuery('#thank_you_msg').html(result.msg);
          // if(result.status=="success"){
          //   jQuery('#thank_you_msg').html(result.msg);
          //  }
        }
      })
    });

    function applyCouponCode() {
      jQuery('#coupon_code_msg').html('');
      jQuery('#order_place_msg').html('');
      var coupon_code = jQuery('#coupon_code').val();
      if (coupon_code != '') {
        jQuery.ajax({
          type: 'post',
          url: '/apply_coupon_code',
          data: 'coupon_code=' + coupon_code + '&_token=' + jQuery("[name='_token']").val(),
          success: function(result) {
            if (result.status == 'success') {
              jQuery('.show_coupon_box').removeClass('hide');
              jQuery('#coupon_code_str').html(coupon_code);
              jQuery('#total_price').html('Rs. ' + result.totalPrice);
              jQuery('.apply_coupon_code_box').hide();
            } else {

            }
            jQuery('#coupon_code_msg').html(result.msg);
          }
        });
      } else {
        jQuery('#coupon_code_msg').html('Please Enter Coupon Code');
      }
    }

    function remove_coupon_code() {
      jQuery('#coupon_code_msg').html('');
      var coupon_code = jQuery('#coupon_code').val();
      jQuery('#coupon_code').val('');
      if (coupon_code != '') {
        jQuery.ajax({
          type: 'post',
          url: '/remove_coupon_code',
          data: 'coupon_code=' + coupon_code + '&_token=' + jQuery("[name='_token']").val(),
          success: function(result) {
            if (result.status == 'success') {
              jQuery('.show_coupon_box').addClass('hide');
              jQuery('#coupon_code_str').html('');
              jQuery('#total_price').html('Rs. ' + result.totalPrice);
              jQuery('.apply_coupon_code_box').show();
            } else {

            }
            jQuery('#coupon_code_msg').html(result.msg);
          }
        });
      }
    }

    jQuery(function() {
      if ($('body').is('.productPage')) {
        var skipSlider = document.getElementById('skipstep');

        var filter_price_start = jQuery('#filter_price_start').val();
        var filter_price_end = jQuery('#filter_price_end').val();
        if (filter_price_start == '' || filter_price_end == '') {
          filter_price_start = 0;
          filter_price_end = 2000;
        }
        noUiSlider.create(skipSlider, {
          range: {
            'min': 0,
            '10%': 100,
            '20%': 300,
            '30%': 500,
            '40%': 700,
            '50%': 900,
            '60%': 1100,
            '70%': 1300,
            '80%': 1500,
            '90%': 1700,
            'max': 2000
          },
          snap: true,
          connect: true,
          start: [filter_price_start, filter_price_end]
        });
        // for value print
        var skipValues = [
          document.getElementById('skip-value-lower'),
          document.getElementById('skip-value-upper')
        ];

        skipSlider.noUiSlider.on('update', function(values, handle) {
          skipValues[handle].innerHTML = values[handle];
        });
      }
    });

    jQuery('#frmPlaceOrder').submit(function(e) {
      jQuery('#order_place_msg').html('Please wait...');
      e.preventDefault();
      jQuery.ajax({
        url: '/place_order',
        data: jQuery('#frmPlaceOrder').serialize(),
        type: 'post',
        success: function(result) {
          jQuery('#thank_you_msg').html(result.msg);
          if (result.status == "success") {
            if (result.payment_url != '') {
              window.location.href = result.payment_url;
            } else {
              window.location.href = "/order_placed";
            }
          }
          jQuery('#order_place_msg').html(result.msg);
        }
      })
    });

    jQuery('#frmProductReview').submit(function(e) {
      //jQuery('#thank_you_msg').html('');
      e.preventDefault();
      jQuery.ajax({
        url: '/product_review_process',
        data: jQuery('#frmProductReview').serialize(),
        type: 'post',
        success: function(result) {
          jQuery('#thank_you_msg').html(result.msg);
          if (result.status == "success") {
            jQuery('.field_error').html(result.msg);
            jQuery('#frmProductReview')[0].reset();
            setInterval(function() {
              window.location.href = window.location.href
            }, 3000);
          }
          if (result.status == "error") {
            jQuery('.field_error').html(result.msg);
          }
        }
      })
    });
  </script>

</body>

</html><?php /**PATH F:\Laragon\www\ecommerce\resources\views/front/layout.blade.php ENDPATH**/ ?>