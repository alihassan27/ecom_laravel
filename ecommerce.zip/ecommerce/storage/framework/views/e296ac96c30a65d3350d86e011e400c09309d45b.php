
<?php $__env->startSection('page_title', 'Order'); ?>
<?php $__env->startSection('container'); ?>

<!-- Cart view section -->
<section id="cart-view">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="cart-view-area">
          <div class="cart-view-table">
            <form action="">
              <div class="table-responsive">
                <table class="table">
                  <thead>
                    <tr>
                      <th>Order ID</th>
                      <th>Order Status</th>
                      <th>Payment Status</th>
                      <th>Total Amt</th>
                      <th>Payment ID</th>
                      <th>Placed At</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="order_id_btn"> <a href="<?php echo e(url('order_detail')); ?>/<?php echo e($list->id); ?>"><?php echo e($list->id); ?></a></td>
                      <td><?php echo e($list->orders_status); ?></td>
                      <td><?php echo e($list->payment_status); ?></td>
                      <td><?php echo e($list->total_amt); ?></td>
                      <td><?php echo e($list->payment_id); ?></td>
                      <td><?php echo e($list->added_on); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- / Cart view section -->

<input type="hidden" name="qty" id="qty" value="1">
<!-- / size and color id's -->
<form action="" id="frmAddToCart">
  <input type="hidden" id="size_id" name="size_id">
  <input type="hidden" id="color_id" name="color_id">
  <input type="hidden" id="pqty" name="pqty">
  <input type="hidden" id="product_id" name="product_id">
  <?php echo csrf_field(); ?>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laragon\www\ecommerce\resources\views/front/order.blade.php ENDPATH**/ ?>