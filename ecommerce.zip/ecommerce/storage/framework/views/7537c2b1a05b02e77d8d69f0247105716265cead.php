
<?php $__env->startSection('page_title','Order'); ?>
<?php $__env->startSection('container'); ?>
<?php $__env->startSection('order_select', 'active'); ?>


<h1 class="mb10">Orders</h1>
<div class="row m-t-30">
    <div class="col-md-12">
        <!-- DATA TABLE-->
        <div class="table-responsive m-b-40">
            <table class="table table-borderless table-data3">
                <thead>
                    <tr>
                      <th>Order ID</th>
                      <th>Customer Details</th>
                      <th>Order Status</th>
                      <th>Payment Status</th>
                      <th>Total Amt</th>
                      <th>Payment ID</th>
                      <th>Placed At</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="order_id_btn"> <a href="<?php echo e(url('admin/order_detail')); ?>/<?php echo e($list->id); ?>"><?php echo e($list->id); ?></a></td>
                      <td>
                        <?php echo e($list->name); ?> <br>
                        <?php echo e($list->email); ?> <br>
                        <?php echo e($list->mobile); ?> <br>
                        <?php echo e($list->address); ?>, <?php echo e($list->city); ?>, <?php echo e($list->state); ?>, <?php echo e($list->pincode); ?>

                    </td>
                      <td><?php echo e($list->orders_status); ?></td>
                      <td><?php echo e($list->payment_status); ?></td>
                      <td><?php echo e($list->total_amt); ?></td>
                      <td><?php echo e($list->payment_id); ?></td>
                      <td><?php echo e($list->added_on); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <!-- END DATA TABLE-->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laragon\www\ecommerce\resources\views/admin/order.blade.php ENDPATH**/ ?>