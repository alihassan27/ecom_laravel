
<?php $__env->startSection('page_title','Manage Category'); ?>
<?php $__env->startSection('category_select', 'active'); ?>
<?php $__env->startSection('container'); ?>
<h1 class="mb10">Manage Category</h1>
<a href="<?php echo e(url('admin/category')); ?>">
    <button type="button" class="btn btn-success">Back</button>
</a>
<div class="row m-t-30">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('category.manage_category_process')); ?>" enctype="multipart/form-data" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label for="category_name" class="control-label mb-1">Category Name</label>
                                <input id="category_name" name="category_name" value="<?php echo e($category_name); ?>" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                            </div>
                            <div class="col-md-4">
                                <label for="parent_category_id" class="control-label mb-1">Parent Category</label>
                                <select name="parent_category_id" id="parent_category_id" class="form-control">
                                    <option value="0">Select Category</option>
                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($parent_category_id==$list->id): ?>
                                    <option selected value="<?php echo e($list->id); ?>"><?php echo e($list->category_name); ?></option>
                                    <?php else: ?>
                                    <option value="<?php echo e($list->id); ?>"><?php echo e($list->category_name); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="category_slug" class="control-label mb-1">Category Slug</label>
                                <input id="category_slug" name="category_slug" value="<?php echo e($category_slug); ?>" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                <?php $__errorArgs = ['category_slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e($message); ?>}
                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-12">
                                <label for="category_image" class="control-label mb-1">Category Image</label>
                                <input id="category_image" name="category_image" type="file" class="form-control" aria-required="true" aria-invalid="false">
                                <?php if($category_image!=''): ?>
                                    <a href="<?php echo e(asset('storage/media/category/'.$category_image)); ?>" target="_blank"><img src="<?php echo e(asset('storage/media/category/'.$category_image)); ?>" / width="100px" alt=""></a>
                                    <?php endif; ?>
                                <?php $__errorArgs = ['category_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e($message); ?>}
                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4 mt-2">
                                <label for="is_home" class="control-label mb-1">Show in Home Page</label>
                                <input id="is_home" name="is_home" type="checkbox" <?php echo e($is_home_selected); ?>>
                            </div>
                        </div>
                    </div>


                    <div>
                        <button id="button" type="submit" name="submit" class="btn btn-lg btn-info btn-block">
                            Submit
                        </button>
                    </div>
                    <input type="hidden" name="id" value="<?php echo e($id); ?>">
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laragon\www\ecommerce\resources\views/admin/manage_category.blade.php ENDPATH**/ ?>