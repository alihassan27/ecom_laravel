@extends('admin.layout')
@section('page_title','Dashboard')
@section('dashboard', 'active')
@section('container')
<div class="row">
    <h1>Dashboard</h1>
</div>
@endsection