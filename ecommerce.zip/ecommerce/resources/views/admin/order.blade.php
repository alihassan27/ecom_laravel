@extends('admin.layout')
@section('page_title','Order')
@section('container')
@section('order_select', 'active')


<h1 class="mb10">Orders</h1>
<div class="row m-t-30">
    <div class="col-md-12">
        <!-- DATA TABLE-->
        <div class="table-responsive m-b-40">
            <table class="table table-borderless table-data3">
                <thead>
                    <tr>
                      <th>Order ID</th>
                      <th>Customer Details</th>
                      <th>Order Status</th>
                      <th>Payment Status</th>
                      <th>Total Amt</th>
                      <th>Payment ID</th>
                      <th>Placed At</th>
                    </tr>
                </thead>
                <tbody>
                @foreach($orders as $list)
                    <tr>
                      <td class="order_id_btn"> <a href="{{url('admin/order_detail')}}/{{$list->id}}">{{$list->id}}</a></td>
                      <td>
                        {{$list->name}} <br>
                        {{$list->email}} <br>
                        {{$list->mobile}} <br>
                        {{$list->address}}, {{$list->city}}, {{$list->state}}, {{$list->pincode}}
                    </td>
                      <td>{{$list->orders_status}}</td>
                      <td>{{$list->payment_status}}</td>
                      <td>{{$list->total_amt}}</td>
                      <td>{{$list->payment_id}}</td>
                      <td>{{$list->added_on}}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <!-- END DATA TABLE-->
    </div>
</div>
@endsection