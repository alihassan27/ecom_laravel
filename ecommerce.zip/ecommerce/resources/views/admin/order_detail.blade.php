@extends('admin.layout')
@section('page_title','Order Details')
@section('container')
@section('order_select', 'active')


<h1 class="mb10">Orders - {{ $orders_details[0]->id }}</h1>

<div class="mt-4 bg-white p-4">
    <b>Update Order Status</b>
    <select class="form-control mb-3" onchange="update_order_status('{{$orders_details[0]->id}}')" id="order_status">
    <?php
        foreach($orders_status as $list)
        if($orders_details[0]->order_status==$list->id){
            echo "<option value='".$list->id."' selected>".$list->orders_status."</option>";
        }else{
        echo "<option value='".$list->id."'>".$list->orders_status."</option>";
        }
        ?>
    </select> 

    <b>Update Payment Status</b>
    <select class="form-control mb-3" onchange="update_payment_status('{{$orders_details[0]->id}}')" id="payment_status">
        <?php
        foreach($payment_status as $list)
        if($orders_details[0]->payment_status==$list){
            echo "<option value='$list' selected>$list</option>";
        }else{
        echo "<option value='$list'>$list</option>";
        }
        ?>
    </select> 

    <b>Track Details</b>
    <form method="POST">
    <textarea class="form-control" name="track_details" required>{{$orders_details[0]->track_details}}</textarea>
    <input class="btn mt-2" type="submit" name="submit" value="Update">
    @csrf
    </form>
</div>

<div class="row m-t-30 bg-white p-4">
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-6">
                <div class="order_detail">
                    <h3>Delivery Address</h3>
                    Name: {{ $orders_details[0]->name }} <br>
                    Address: {{ $orders_details[0]->address }} <br>
                    City: {{ $orders_details[0]->city }} <br>
                    State: {{ $orders_details[0]->state }} <br>
                    Pincode: {{ $orders_details[0]->pincode }} <br>
                    Mobile: {{ $orders_details[0]->mobile }} <br>
                </div>
            </div>

            <div class="col-md-6">
                <div class="order_detail">
                    <h3>Order Details</h3>
                    Order Status: {{ $orders_details[0]->orders_status }} <br>
                    Payment Status: {{ $orders_details[0]->payment_status }} <br>
                    Payment Type: {{ $orders_details[0]->payment_type }} <br>
                    <?php
                    if ($orders_details[0]->payment_id != '') {
                        echo 'Payment ID: ' . $orders_details[0]->payment_id;
                    }
                    ?>
                </div>
            </div>

            <div class="col-md-12">
                <div class="cart-view-area">
                    <div class="cart-view-table">
                        <form action="">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Product</th>
                                            <th>Image</th>
                                            <th>Size</th>
                                            <th>Color</th>
                                            <th>Price</th>
                                            <th>Qty</th>
                                            <th>Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @php
                                        $totalAmt = 0;
                                        @endphp
                                        @foreach($orders_details as $list)
                                        @php
                                        $totalAmt = $totalAmt + ($list->price * $list->qty);
                                        @endphp
                                        <tr>
                                            <td>{{$list->pname}}</td>
                                            <td><img src='{{asset('storage/media/'.$list->attr_image)}}' alt="" width="120px"></td>
                                            <td>{{$list->size}}</td>
                                            <td>{{$list->color}}</td>
                                            <td>{{$list->price}}</td>
                                            <td>{{$list->qty}}</td>
                                            <td>{{$list->price * $list->qty}}</td>

                                        </tr>
                                        @endforeach
                                        <tr>
                                            <td colspan="5">&nbsp;</td>
                                            <td><b>Total</b></td>
                                            <td><b>{{$totalAmt}}</b></td>
                                        </tr>

                                        <?php
                                        if ($orders_details[0]->coupon_value > 0) {
                                            echo '<tr>
                    <td colspan="5">&nbsp;</td>
                    <td><b>Coupon <span class="cart_color">(' . $orders_details[0]->coupon_code . ')</span></b></td>
                    <td>' . $orders_details[0]->coupon_value . '</td>
                    </tr>';
                                            $totalAmt = $totalAmt - $orders_details[0]->coupon_value;
                                            echo '<tr>
                    <td colspan="5">&nbsp;</td>
                    <td><b>Final Total</b></td>
                    <td><b>' . $totalAmt . '</b></td>
                    </tr>';
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection