@extends('admin.layout')
@section('page_title','Manage Product')
@section('product_select', 'active')
@section('container')

@if($id>0)
{{$image_required=""}}

@else
{{$image_required="required"}}
@endif

<h1 class="mb10">Manage Product</h1>
@if(session()->has('sku_error'))
<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
    {{session('sku_error')}}
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
    </button>
</div>
@endif

@error('attr_image.*')
<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
    {{$message}}
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
    </button>
</div>
@enderror

@error('images.*')
<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
    {{$message}}
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">×</span>
    </button>
</div>
@enderror

<a href="{{url('admin/product')}}">
    <button type="button" class="btn btn-success">Back</button>
</a>
<script src="{{ asset('ckeditor/ckeditor.js')}}"></script>
<div class="row m-t-30">
    <div class="col-md-12">

        <form action="{{route('product.manage_product_process')}}" enctype="multipart/form-data" method="POST">

            <div class="card">
                <div class="card-body">
                    @csrf
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-6">
                                <label for="name" class="control-label mb-1">Name</label>
                                <input id="name" name="name" value="{{$name}}" type="text" class="form-control" aria-required="true" aria-invalid="false" required>

                                @error('name')
                                <div class="alert alert-danger" role="alert">
                                    {{$message}}}
                                </div>
                                @enderror
                            </div>

                            <div class="col-md-6">
                                <label for="slug" class="control-label mb-1">Slug</label>
                                <input id="slug" name="slug" value="{{$slug}}" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                @error('slug')
                                <div class="alert alert-danger" role="alert">
                                    {{$message}}}
                                </div>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="image" class="control-label mb-1">Image</label>
                        <input id="image" name="image" type="file" class="form-control" aria-required="true" aria-invalid="false" {{$image_required}}>
                        @error('image')
                        <div class="alert alert-danger" role="alert">
                            {{$message}}}
                        </div>
                        @enderror
                        @if($image !='')
                        <a href="{{ asset('storage/media/'.$image)}}" target="_blank"><img src="{{ asset('storage/media/'.$image)}}" / width="100px" alt=""></a>
                        @endif
                    </div>

                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label for="category_id" class="control-label mb-1">Category</label>
                                <select name="category_id" id="category_id" class="form-control" required>
                                    <option value="">Select Category</option>
                                    @foreach($category as $list)
                                    @if($category_id==$list->id)
                                    <option selected value="{{$list->id}}">{{$list->category_name}}</option>
                                    @else
                                    <option value="{{$list->id}}">{{$list->category_name}}</option>
                                    @endif
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-md-4">
                                <label for="brand" class="control-label mb-1">Brand</label>
                                <select name="brand" id="brand" class="form-control" required>
                                    <option value="">Select Brand</option>
                                    @foreach($brands as $list)
                                    @if($brand == $list->id)
                                    <option selected value="{{$list->id}}">{{$list->name}}</option>
                                    @else
                                    <option value="{{$list->id}}">{{$list->name}}</option>
                                    @endif
                                    @endforeach
                                </select>
                            </div>

                            <div class="col-md-4">
                                <label for="model" class="control-label mb-1">Model</label>
                                <input id="model" name="model" value="{{$model}}" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                            </div>
                        </div>

                    </div>

                    <div class="form-group">
                        <label for="short_desc" class="control-label mb-1">Short Desc</label>
                        <textarea id="short_desc" name="short_desc" type="text" class="form-control" aria-required="true" aria-invalid="false" required>{{$short_desc}}</textarea>
                    </div>

                    <div class="form-group">
                        <label for="desc" class="control-label mb-1">Desc</label>
                        <textarea id="desc" name="desc" type="text" class="form-control" aria-required="true" aria-invalid="false" required>{{$desc}}</textarea>
                    </div>

                    <div class="form-group">
                        <label for="keywords" class="control-label mb-1">Keywords</label>
                        <textarea id="keywords" name="keywords" type="text" class="form-control" aria-required="true" aria-invalid="false" required>{{$keywords}}</textarea>
                    </div>

                    <div class="form-group">
                        <label for="technical_specification" class="control-label mb-1">Technical Specification</label>
                        <textarea id="technical_specification" name="technical_specification" type="text" class="form-control" aria-required="true" aria-invalid="false" required>{{$technical_specification}}</textarea>
                    </div>

                    <div class="form-group">
                        <label for="uses" class="control-label mb-1">Uses</label>
                        <textarea id="uses" name="uses" type="text" class="form-control" aria-required="true" aria-invalid="false" required>{{$uses}}</textarea>
                    </div>

                    <div class="form-group">
                        <label for="warranty" class="control-label mb-1">Warranty</label>
                        <textarea id="warranty" name="warranty" type="text" class="form-control" aria-required="true" aria-invalid="false" required>{{$warranty}}</textarea>
                    </div>

                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label for="lead_time" class="control-label mb-1">Lead Time</label>
                                <input id="lead_time" name="lead_time" value="{{$lead_time}}" type="text" class="form-control" aria-required="true" aria-invalid="false">
                            </div>
                            <div class="col-md-4">
                                <label for="tax_id" class="control-label mb-1">Tax</label>
                                <select name="tax_id" id="tax_id" class="form-control" required>
                                    <option value="">Select Tax</option>
                                    @foreach($taxes as $list)
                                    @if($tax_id == $list->id)
                                    <option selected value="{{$list->id}}">{{$list->tax_desc}}</option>
                                    @else
                                    <option value="{{$list->id}}">{{$list->tax_desc}}</option>
                                    @endif
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="is_promo" class="control-label mb-1">Is Promo</label>
                                <select name="is_promo" id="is_promo" class="form-control" required>
                                    @if($is_promo=='1')
                                    <option selected value="1">Yes</option>
                                    <option value="0">No</option>
                                    @else
                                    <option value="1">Yes</option>
                                    <option selected value="0">No</option>
                                    @endif
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-4">
                                <label for="is_featured" class="control-label mb-1">Is Featured</label>
                                <select name="is_featured" id="is_featured" class="form-control" required>
                                    @if($is_featured=='1')
                                    <option selected value="1">Yes</option>
                                    <option value="0">No</option>
                                    @else
                                    <option value="1">Yes</option>
                                    <option selected value="0">No</option>
                                    @endif
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="is_discounted" class="control-label mb-1">Is Discounted</label>
                                <select name="is_discounted" id="is_discounted" class="form-control" required>
                                    @if($is_discounted=='1')
                                    <option selected value="1">Yes</option>
                                    <option value="0">No</option>
                                    @else
                                    <option value="1">Yes</option>
                                    <option selected value="0">No</option>
                                    @endif
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="is_tranding" class="control-label mb-1">Is Tranding</label>
                                <select name="is_tranding" id="is_tranding" class="form-control" required>
                                    @if($is_tranding=='1')
                                    <option selected value="1">Yes</option>
                                    <option value="0">No</option>
                                    @else
                                    <option value="1">Yes</option>
                                    <option selected value="0">No</option>
                                    @endif
                                </select>
                            </div>
                        </div>

                        <h2 class="mb10">Product Images</h2>
                        <div class="col-md-12 m-0 p-0">

                            <div class="card">
                                <div class="card-body">
                                    <div class="form-group">
                                        <div class="row" id="product_images_box">

                                            @php
                                            $loop_count_num = 1;
                                            @endphp

                                            @foreach($productImagesArr as $key=>$val)
                                            @php
                                            $loop_count_prev = $loop_count_num;
                                            $pIArr = (array)$val;
                                            @endphp

                                            <input type="hidden" id="piid" name="piid[]" value="{{$pIArr['id']}}">
                                            <div class="col-md-4 product_images_{{$loop_count_num++}}">
                                                <label for="images" class="control-label mb-1">Image</label>
                                                <input id="images" name="images[]" type="file" class="form-control" aria-required="true" aria-invalid="false" {{$image_required}}>
                                                @if($pIArr['images']!='')
                                                <a href="{{ asset('storage/media/'.$pIArr['images'])}}" target="_blank"><img src="{{ asset('storage/media/'.$pIArr['images'])}}" / width="100px" alt=""></a>
                                                @endif
                                            </div>

                                            <div class="col-md-2">
                                                <label for="" class="control-label mb-1"></label> <br>
                                                @if($loop_count_num==2)
                                                <button type="button" class="btn btn-success btn-lg" onclick="add_images_more()">
                                                    <i class="fa fa-plus"></i>&nbsp;Add</button>
                                                @else
                                                <a href="{{url('admin/product/product_images_delete/')}}/{{$pIArr['id']}}/{{$id}}">
                                                    <button type="button" class="btn btn-danger btn-lg">
                                                        <i class="fa fa-minus"></i>&nbsp;Remove</button> </a>
                                                @endif
                                            </div>
                                            @endforeach
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <input type="hidden" name="id" value="{{$id}}">
                        <h2 class="mb10">Product Attributes</h2>
                        <div class="col-md-12 m-0 p-0" id="product_attr_box">

                            @php
                            $loop_count_num = 1;
                            @endphp

                            @foreach($product_AttrArr as $key=>$val)
                            @php
                            $loop_count_prev = $loop_count_num;
                            $pAArr = (array)$val;
                            @endphp

                            <input type="hidden" id="paid" name="paid[]" value="{{$pAArr['id']}}">

                            <div class="card" id="product_attr_{{$loop_count_num++}}">
                                <div class="card-body">
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-md-2">
                                                <label for="sku" class="control-label mb-1">SKU</label>
                                                <input id="sku" name="sku[]" value="{{$pAArr['sku']}}" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                            </div>

                                            <div class="col-md-2">
                                                <label for="mrp" class="control-label mb-1">MRP</label>
                                                <input id="mrp" name="mrp[]" value="{{$pAArr['mrp']}}" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                            </div>

                                            <div class="col-md-2">
                                                <label for="price" class="control-label mb-1">Price</label>
                                                <input id="price" name="price[]" value="{{$pAArr['price']}}" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                            </div>

                                            <div class="col-md-3">
                                                <label for="size_id" class="control-label mb-1">Size</label>
                                                <select name="size_id[]" id="size_id" class="form-control">
                                                    <option value="">Select Size</option>
                                                    @foreach($sizes as $list)
                                                    @if($pAArr['size_id']==$list->id){
                                                    <option selected value="{{$list->id}}">{{$list->size}}</option>
                                                    }
                                                    @else{
                                                    <option value="{{$list->id}}">{{$list->size}}</option>
                                                    }
                                                    @endif
                                                    @endforeach
                                                </select>
                                            </div>

                                            <div class="col-md-3">
                                                <label for="color_id" class="control-label mb-1">Color</label>
                                                <select name="color_id[]" id="color_id" class="form-control">
                                                    <option value="">Select Color</option>
                                                    @foreach($colors as $list)
                                                    @if($pAArr['color_id']==$list->id){
                                                    <option selected value="{{$list->id}}">{{$list->color}}</option>
                                                    }
                                                    @else{
                                                    <option value="{{$list->id}}">{{$list->color}}</option>
                                                    }
                                                    @endif
                                                    @endforeach
                                                </select>
                                            </div>

                                            <div class="col-md-2">
                                                <label for="qty" class="control-label mb-1">QTY</label>
                                                <input id="qty" name="qty[]" value="{{$pAArr['qty']}}" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
                                            </div>

                                            <div class="col-md-4">
                                                <label for="attr_image" class="control-label mb-1">Image</label>
                                                <input id="attr_image" name="attr_image[]" type="file" class="form-control" aria-required="true" aria-invalid="false" {{$image_required}}>
                                                @if($pAArr['attr_image']!='')
                                                <img src="{{ asset('storage/media/'.$pAArr['attr_image'])}}" / width="100px" alt="">
                                                @endif
                                            </div>

                                            <div class="col-md-2">
                                                <label for="" class="control-label mb-1"></label> <br>
                                                @if($loop_count_num==2)
                                                <button type="button" class="btn btn-success btn-lg" onclick="add_more()">
                                                    <i class="fa fa-plus"></i>&nbsp;Add</button>
                                                @else
                                                <a href="{{url('admin/product/product_attr_delete/')}}/{{$pAArr['id']}}/{{$id}}">
                                                    <button type="button" class="btn btn-danger btn-lg">
                                                        <i class="fa fa-minus"></i>&nbsp;Remove</button> </a>
                                                @endif
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endforeach
                        </div>
                        <div>
                            <button id="button" type="submit" name="submit" class="btn btn-lg btn-info btn-block">
                                Submit
                            </button>
                        </div>

        </form>

    </div>
</div>

<script>
    var loop_count = 1;

    function add_more() {
        loop_count++;
        var html = '<input type="text" id="paid" name="paid[]"><div class="card" id="product_attr_' + loop_count + '"><div class="card-body"><div class="form-group"><div class="row">';

        html += '<div class="col-md-2"><label for="sku" class="control-label mb-1">SKU</label><input id="sku" name="sku[]" value="" type="text" class="form-control" aria-required="true" aria-invalid="false" required></div>';

        html += '<div class="col-md-2"><label for="mrp" class="control-label mb-1">MRP</label><input id="mrp" name="mrp[]" value="" type="text" class="form-control" aria-required="true" aria-invalid="false" required></div>';

        html += '<div class="col-md-2"><label for="price" class="control-label mb-1">Price</label><input id="price" name="price[]" value="" type="text" class="form-control" aria-required="true" aria-invalid="false" required></div>';

        var size_id_html = $('#size_id').html();
        size_id_html = size_id_html.replace('selected', '');
        html += '<div class="col-md-3"><label for="size_id" class="control-label mb-1">Size</label><select name="size_id[]" id="size_id" class="form-control">' + size_id_html + '</select></div>';

        var color_id_html = $('#color_id').html();
        color_id_html = color_id_html.replace('selected', '');
        html += '<div class="col-md-3"><label for="color_id" class="control-label mb-1">Color</label><select name="color_id[]" id="color_id" class="form-control">' + color_id_html + '</select></div>';

        html += '<div class="col-md-2"><label for="qty" class="control-label mb-1">QTY</label><input id="qty" name="qty[]" value="" type="text" class="form-control" aria-required="true" aria-invalid="false" required></div>';

        html += '<div class="col-md-4"><label for="attr_image" class="control-label mb-1">Image</label><input id="attr_image" name="attr_image[]" value="" type="file" class="form-control" aria-required="true" aria-invalid="false" required></div>';

        html += '<div class="col-md-2"><label for="" class="control-label mb-1"></label> <br><button type="button" class="btn btn-success btn-lg" onclick=remove_more("' + loop_count + '")><i class="fa fa-minus"></i>&nbsp;Remove</button></div>';

        html += '</div></div></div></div>';
        $('#product_attr_box').append(html);
    }

    function remove_more(loop_count) {
        $('#product_attr_' + loop_count).remove();
    }

    var loop_images_count = 1;

    function add_images_more() {
        loop_images_count++;
        var html = '<input type="hidden" id="piid" name="piid[]" value=""><div class="col-md-4 product_images_' + loop_images_count + '"><label for="images" class="control-label mb-1">Image</label><input id="images" name="images[]" value="" type="file" class="form-control" aria-required="true" aria-invalid="false" required></div>';

        html += '<div class="col-md-2 product_images_' + loop_images_count + '"><label for="" class="control-label mb-1"></label> <br><button type="button" class="btn btn-success btn-lg" onclick=remove_images_more("' + loop_images_count + '")><i class="fa fa-minus"></i>&nbsp;Remove</button></div>';
        $('#product_images_box').append(html);
    }

    function remove_images_more(loop_images_count) {
        $('.product_images_' + loop_images_count).remove();
    }

    CKEDITOR.replace('short_desc');
    // CKEDITOR.replace('desc');
    // CKEDITOR.replace('technical_specification');
</script>

@endsection