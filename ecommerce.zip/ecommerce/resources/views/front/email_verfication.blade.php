Welcome {{$name}} <br>
<a href="{{url('/verification/')}}/{{$rand_id}}">Click here</a> to verifiy your email id. <br>
