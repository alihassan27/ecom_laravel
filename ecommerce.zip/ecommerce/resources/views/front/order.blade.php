@extends('front/layout')
@section('page_title', 'Order')
@section('container')

<!-- Cart view section -->
<section id="cart-view">
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="cart-view-area">
          <div class="cart-view-table">
            <form action="">
              <div class="table-responsive">
                <table class="table">
                  <thead>
                    <tr>
                      <th>Order ID</th>
                      <th>Order Status</th>
                      <th>Payment Status</th>
                      <th>Total Amt</th>
                      <th>Payment ID</th>
                      <th>Placed At</th>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach($orders as $list)
                    <tr>
                      <td class="order_id_btn"> <a href="{{url('order_detail')}}/{{$list->id}}">{{$list->id}}</a></td>
                      <td>{{$list->orders_status}}</td>
                      <td>{{$list->payment_status}}</td>
                      <td>{{$list->total_amt}}</td>
                      <td>{{$list->payment_id}}</td>
                      <td>{{$list->added_on}}</td>
                    </tr>
                    @endforeach
                  </tbody>
                </table>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- / Cart view section -->

<input type="hidden" name="qty" id="qty" value="1">
<!-- / size and color id's -->
<form action="" id="frmAddToCart">
  <input type="hidden" id="size_id" name="size_id">
  <input type="hidden" id="color_id" name="color_id">
  <input type="hidden" id="pqty" name="pqty">
  <input type="hidden" id="product_id" name="product_id">
  @csrf
</form>
@endsection