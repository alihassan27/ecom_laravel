Welcome {{$name}} <br>
Your Password: {{$password}}