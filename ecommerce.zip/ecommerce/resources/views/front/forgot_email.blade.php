<a href="{{url('/forgot_password_change/')}}/{{$rand_id}}">Click here</a> to change your password. <br>
