@extends('front/layout')
@section('page_title', 'Category Page')
@section('container')

<!-- product category -->
<section id="aa-product-category">
    <div class="container">
        <div class="row" style="text-align: center;">
            <br> <br> <br>
           <h2>Your email is verified successfully.</h2>
            <br> <br> <br>
        </div>
    </div>
</section>
@endsection